const readline = require('readline');
const { exec } = require('child_process');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function displayPrompt() {
  process.stdout.write('\x1b[20mroot@fatzxx~# \x1b[1m');
}

function executeCommand(command, url, time, thread, rate) {
  if (command === 'mix') {
    console.log(`
\x1b[35m        ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗\x1b[0m
\x1b[35m        ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║ \x1b[0m
\x1b[35m        ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩ \x1b[0m
           \x1b[31mATTACK HAS BEEN STARTED! \x1b[0m
   \x1b[24m╚═════\x1b[0m\x1b[31m╦═══════════════════════════╦\x1b[0m\x1b[24m═════╝\x1b[0m
\x1b[24m╔════════\x1b[0m\x1b[31m╩═══════════════════════════╩\x1b[0m\x1b[24m════════╗\x1b[0m
      \x1b[37mTARGET       : [ ${url} ]\x1b[0m
      \x1b[37mTIME         : [ ${time} ]\x1b[0m
      \x1b[37mTHREAD       : [ ${thread} ]\x1b[0m
      \x1b[37mRATE         : [ ${rate} ]\x1b[0m
      \x1b[37mMETHOD       : [ MIX ]\x1b[0m
      \x1b[37mVIP          : [ TRUE ]\x1b[0m
      \x1b[37mUSER         : [ FATZXX ]\x1b[0m
\x1b[24m╚══════════════════════════════════════════════╝\x1b[0m
      `);
    const filePath = __dirname + '/mix.js';
    exec(`node ${filePath} ${url} ${time} ${thread} ${rate}`, (error, stdout, stderr) => {
      if (error) {
        console.error(`Error: ${error.message}`);
        return;
      }
      if (stderr) {
        console.error(`stderr: ${stderr}`);
        return;
      }
      console.log(stdout);

      // Tampilkan ASCII art "ATTACK SENT" setelah mix.js selesai dieksekusi

      displayPrompt();
    });
  } else {
    console.log(`Perintah ${command} belum diimplementasikan.`);
    displayPrompt();
  }
}

function displayHelp() {
  console.log('=== Menu Help ===');
  console.log('1. mix - Menjalankan file mix.js');
  console.log('2. url - Memasukkan URL');
  console.log('3. time - Mengatur waktu');
  console.log('4. thread - Mengatur jumlah thread');
  console.log('5. rate - Mengatur rate');
  console.log('6. help - Menampilkan menu help');
  console.log('================');
  displayPrompt();
}

// ASCII art REXCGOD
console.log(`
  \x1b[35m
⠄⣾⣿⡇⢸⣿⣿⣿⠄⠈⣿⣿⣿⣿⠈⣿⡇⢹⣿⣿⣿⡇⡇⢸⣿⣿⡇⣿⣿⣿
⢠⣿⣿⡇⢸⣿⣿⣿⡇⠄⢹⣿⣿⣿⡀⣿⣧⢸⣿⣿⣿⠁⡇⢸⣿⣿⠁⣿⣿⣿
⢸⣿⣿⡇⠸⣿⣿⣿⣿⡄⠈⢿⣿⣿⡇⢸⣿⡀⣿⣿⡿⠸⡇⣸⣿⣿⠄⣿⣿⣿
⢸⣿⡿⠷⠄⠿⠿⠿⠟⠓⠰⠘⠿⣿⣿⡈⣿⡇⢹⡟⠰⠦⠁⠈⠉⠋⠄⠻⢿⣿
⢨⡑⠶⡏\x1b[31mMix Method \x1b[7mFixxed \x1b[1m⠂⠘⠉⠿⠖
⠈⠉⠄⡀⠄⣀⣀⣀⣀⠈⢛⣿⣿⣿⣿⣿⣿⣿⣿⣟⠁⣀⣤⣤⣠⡀⠄⡀⠈
⠄⠠⣾⡀⣾⣿⣧⣼⣿⡿⢠User : Fatzxx⣼⣿⣿⢀⣿⡇⠄
⡀⠄⠻⣷⡘⢿⣿⣿⡿⢣⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣜⢿⣿⣿⡿⢃⣾⠟⢁⠈
⢃⢻⣶⣬⣿⣶⣬⣥⣶⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣿⣷⣶⣶⣾⣿⣷⣾⣾⢣
╚════════════════════════════╝
        \x1b[37m🔥Powerfull 🔥
   ╚═════════════════════╝
`);

displayPrompt();

let url = '';
let time = '';
let thread = '';
let rate = '';

rl.on('line', (input) => {
  const args = input.split(' ');
  const command = args[0];

  if (command === 'help') {
    displayHelp();
  } else if (command === 'mix') {
    if (args.length !== 5) {
      console.log('Format command mix salah. Gunakan format: mix <url> <time> <thread> <rate>');
      displayPrompt();
    } else {
      executeCommand(args[0], args[1], args[2], args[3], args[4]);
    }
  } else if (!url) {
    url = input;
    console.log('URL telah ditetapkan:', url);
    process.stdout.write('Masukkan waktu: ');
  } else if (!time) {
    time = input;
    console.log('Waktu telah ditetapkan:', time);
    process.stdout.write('Masukkan jumlah thread: ');
  } else if (!thread) {
    thread = input;
    console.log('Jumlah thread telah ditetapkan:', thread);
    process.stdout.write('Masukkan rate: ');
  } else if (!rate) {
    rate = input;
    console.log('Rate telah ditetapkan:', rate);
    executeCommand('mix', url, time, thread, rate);
    url = '';
    time = '';
    thread = '';
    rate = '';
  }
});
